<?php
header('Content-Type: application/json');

include('DBconfig.php');

$query = sprintf("select c.Nom,d.d1,d.d2,d.d3,d.d4,d.d5,d.d6,d.d7,d.d8,d.d9,d.d10,d.d11,d.d12,d.d13,d.d14,d.d15,d.d16,d.d17,d.d18,d.d19,d.d20,d.d21,d.d22,d.d23,d.d24,d.d25,d.d26,d.d27,d.d28,d.d29,d.d30,d.d31 from mytable a, data d,info c where a.uname = 'loki' and a.house=d.house and c.house=a.house");

//execute query
$result = $mysqli_query($query);

//loop through the returned data
$data = array();
foreach ($result as $row) {
  $data[] = $row;
}

//free memory associated with result
$result->close();

//close connection
$mysqli->close();

//now print the data
print json_encode($data);

mysqli_close($conn);

echo json_encode($data);
?>

