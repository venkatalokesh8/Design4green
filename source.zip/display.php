<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Show MySQL DB Data</title>

<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>

<body>

<div class="container">
 
<table class="table table-bordered">
 <thead>
 <tr>
 <th>Nom</th>
 <th>House</th>
 <th>Day1</th><th>Day2</th><th>Day3</th><th>Day4</th><th>Day5</th><th>Day6</th><th>Day7</th><th>Day8</th><th>Day9</th><th>Day10</th><th>Day11</th><th>Day12</th><th>Day13</th><th>Day14</th><th>Day15</th>
 <th>Day16</th><th>Day17</th>
 <th>Day18</th><th>Day19</th><th>Day20</th><th>Day21</th><th>Day22</th><th>Day23</th><th>Day24</th><th>Day25</th><th>Day26</th><th>Day27</th><th>Day28</th><th>Day29</th>
 <th>Day30</th><th>Day31</th>


 </tr>
 </thead>
 <tbody>
 
 <?php
 include('DBconfig.php');
  
  $name = $_SESSION['username'];
 $result = mysql_query("select * from mytable a, data d,info c where a.uname = '$name' and a.house=d.house and c.house=a.house");
 
 $user= mysql_query("SELECT * FROM info a, mytable b where a.house=b.house and b.uname='$name'");
 
 $unom = mysql_fetch_array($user);
 
 while($green = mysql_fetch_array($result))
 {
 //$id = $green['id']; 
 echo "<tr>";
 echo"<td>".$green['Nom']."</td>";
 echo"<td>".$green['house']."</td>";
 echo"<td>".$green['d1']."</td>";
 echo"<td>".$green['d2']."</td>";
 echo"<td>".$green['d3']."</td>";
 echo"<td>".$green['d4']."</td>";
 echo"<td>".$green['d5']."</td>";
 echo"<td>".$green['d6']."</td>";
 echo"<td>".$green['d7']."</td>";
 echo"<td>".$green['d8']."</td>";
 echo"<td>".$green['d9']."</td>";
 echo"<td>".$green['d10']."</td>";
 echo"<td>".$green['d11']."</td>";
 echo"<td>".$green['d12']."</td>";
 echo"<td>".$green['d13']."</td>";
 echo"<td>".$green['d14']."</td>";
 echo"<td>".$green['d15']."</td>";
 echo "<br/>";
 echo"<td>".$green['d16']."</td>";
 echo"<td>".$green['d17']."</td>";
 echo"<td>".$green['d18']."</td>";
 echo"<td>".$green['d19']."</td>";
 echo"<td>".$green['d20']."</td>";
 echo"<td>".$green['d21']."</td>";
 echo"<td>".$green['d22']."</td>";
 echo"<td>".$green['d23']."</td>";
 echo"<td>".$green['d24']."</td>";
 echo"<td>".$green['d25']."</td>";
 echo"<td>".$green['d26']."</td>";
 echo"<td>".$green['d27']."</td>";
 echo"<td>".$green['d28']."</td>";
 echo"<td>".$green['d29']."</td>";
 echo"<td>".$green['d30']."</td>";
 echo"<td>".$green['d31']."</td>";
 
 
 
  
 echo "</tr>";
  
 }
 mysql_close($conn);
 ?>
 
</table>

</div>
</body>
</html>

