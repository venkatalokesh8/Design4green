-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 22, 2019 at 03:56 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `green`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `house` varchar(1) NOT NULL,
  `Nom` varchar(12) DEFAULT NULL,
  `Prenom` varchar(12) DEFAULT NULL,
  `Societe` varchar(27) DEFAULT NULL,
  `Adresse` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`house`, `Nom`, `Prenom`, `Societe`, `Adresse`) VALUES
('A', 'Pierre', 'Martin', NULL, NULL),
('B', NULL, NULL, 'Société HLM de l’Aude (SHA)', NULL),
('C', 'Albert', 'Courcoul', NULL, NULL),
('D', 'Frédéric', 'Marchand', NULL, NULL),
('E', NULL, NULL, 'SCI Arro & Cie', NULL),
('F', 'Jean-Charles', 'Monvoisin', NULL, NULL),
('G', 'Guy', 'Durand', NULL, NULL),
('H', 'Maeva', 'Livet', NULL, NULL),
('I', 'Alizée', 'Lieau', NULL, NULL),
('J', NULL, NULL, 'Aixoise d’HLM', NULL),
('K', NULL, NULL, 'SCI Albert Camus', NULL),
('L', NULL, NULL, 'SCI des Batignolles', NULL),
('M', NULL, NULL, 'BAZELAT HABITAT', NULL),
('N', NULL, NULL, 'PERIGORD HABITAT', NULL),
('O', NULL, NULL, 'SCI des Alouettes', NULL),
('P', 'Alexandre', 'Jaures', NULL, NULL),
('Q', 'Norbert', 'Detressangle', NULL, NULL),
('R', NULL, NULL, 'SCI USSE', NULL),
('S', NULL, NULL, 'SCI THOMSON', NULL),
('T', 'Théodore', 'Javel', NULL, NULL),
('U', NULL, NULL, 'OCCITANIE HLM', NULL),
('V', 'Pascal', 'Alison', NULL, NULL),
('W', 'Dominique', 'Sarment', NULL, NULL),
('X', 'Clément', 'Poirrier', NULL, NULL),
('Y', NULL, NULL, 'MALOUIN HABITAT', NULL),
('Z', 'Gertrude', 'Coréa', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `data`
--

CREATE TABLE `data` (
  `house` varchar(1) NOT NULL,
  `d1` int(11) NOT NULL,
  `d2` int(11) NOT NULL,
  `d3` int(11) NOT NULL,
  `d4` int(11) NOT NULL,
  `d5` int(11) NOT NULL,
  `d6` int(11) NOT NULL,
  `d7` int(11) NOT NULL,
  `d8` int(11) NOT NULL,
  `d9` int(11) NOT NULL,
  `d10` int(11) NOT NULL,
  `d11` int(11) NOT NULL,
  `d12` int(11) NOT NULL,
  `d13` int(11) NOT NULL,
  `d14` int(11) NOT NULL,
  `d15` int(11) NOT NULL,
  `d16` int(11) NOT NULL,
  `d17` int(11) NOT NULL,
  `d18` int(11) NOT NULL,
  `d19` int(11) NOT NULL,
  `d20` int(11) NOT NULL,
  `d21` int(11) NOT NULL,
  `d22` int(11) NOT NULL,
  `d23` int(11) NOT NULL,
  `d24` int(11) NOT NULL,
  `d25` int(11) NOT NULL,
  `d26` int(11) NOT NULL,
  `d27` int(11) NOT NULL,
  `d28` int(11) NOT NULL,
  `d29` int(11) NOT NULL,
  `d30` int(11) NOT NULL,
  `d31` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data`
--

INSERT INTO `data` (`house`, `d1`, `d2`, `d3`, `d4`, `d5`, `d6`, `d7`, `d8`, `d9`, `d10`, `d11`, `d12`, `d13`, `d14`, `d15`, `d16`, `d17`, `d18`, `d19`, `d20`, `d21`, `d22`, `d23`, `d24`, `d25`, `d26`, `d27`, `d28`, `d29`, `d30`, `d31`) VALUES
('A', 1666, 1568, 8027, 2576, 7440, 5291, 9101, 8153, 5817, 9470, 1666, 1568, 8027, 2576, 7440, 5291, 9101, 8153, 5817, 9470, 1666, 1568, 8027, 2576, 7440, 5291, 9101, 8153, 5817, 9470, 1666),
('B', 7958, 4782, 8557, 961, 1293, 747, 9039, 5500, 1080, 4819, 7958, 4782, 8557, 961, 1293, 747, 9039, 5500, 1080, 4819, 7958, 4782, 8557, 961, 1293, 747, 9039, 5500, 1080, 4819, 7958),
('C', 5601, 1874, 5464, 8220, 2301, 6521, 6955, 9242, 7573, 7121, 5601, 1874, 5464, 8220, 2301, 6521, 6955, 9242, 7573, 7121, 5601, 1874, 5464, 8220, 2301, 6521, 6955, 9242, 7573, 7121, 5601),
('D', 6019, 768, 6219, 2041, 7141, 3706, 7342, 4110, 3538, 4574, 6019, 768, 6219, 2041, 7141, 3706, 7342, 4110, 3538, 4574, 6019, 768, 6219, 2041, 7141, 3706, 7342, 4110, 3538, 4574, 6019),
('E', 1834, 1856, 4358, 3568, 6519, 3194, 9869, 1098, 6312, 4736, 1834, 1856, 4358, 3568, 6519, 3194, 9869, 1098, 6312, 4736, 1834, 1856, 4358, 3568, 6519, 3194, 9869, 1098, 6312, 4736, 1834),
('F', 8883, 8775, 938, 6371, 4406, 3483, 4204, 9733, 1492, 4353, 8883, 8775, 938, 6371, 4406, 3483, 4204, 9733, 1492, 4353, 8883, 8775, 938, 6371, 4406, 3483, 4204, 9733, 1492, 4353, 8883),
('G', 2055, 7051, 1102, 5506, 1177, 2441, 2813, 1702, 4856, 8882, 2055, 7051, 1102, 5506, 1177, 2441, 2813, 1702, 4856, 8882, 2055, 7051, 1102, 5506, 1177, 2441, 2813, 1702, 4856, 8882, 2055),
('H', 5267, 4643, 2995, 8441, 9353, 3583, 8588, 8912, 8556, 7530, 5267, 4643, 2995, 8441, 9353, 3583, 8588, 8912, 8556, 7530, 5267, 4643, 2995, 8441, 9353, 3583, 8588, 8912, 8556, 7530, 5267),
('I', 2507, 2005, 4911, 2434, 6381, 3139, 3341, 728, 1926, 2282, 2507, 2005, 4911, 2434, 6381, 3139, 3341, 728, 1926, 2282, 2507, 2005, 4911, 2434, 6381, 3139, 3341, 728, 1926, 2282, 2507),
('J', 809, 3800, 1541, 1146, 7942, 629, 788, 5622, 2774, 9560, 809, 3800, 1541, 1146, 7942, 629, 788, 5622, 2774, 9560, 809, 3800, 1541, 1146, 7942, 629, 788, 5622, 2774, 9560, 809),
('K', 1666, 1568, 8027, 2576, 7440, 5291, 9101, 8153, 5817, 9470, 1666, 1568, 8027, 2576, 7440, 5291, 9101, 8153, 5817, 9470, 1666, 1568, 8027, 2576, 7440, 5291, 9101, 8153, 5817, 9470, 1666),
('L', 7958, 4782, 8557, 961, 1293, 747, 9039, 5500, 1080, 4819, 7958, 4782, 8557, 961, 1293, 747, 9039, 5500, 1080, 4819, 7958, 4782, 8557, 961, 1293, 747, 9039, 5500, 1080, 4819, 7958),
('M', 5601, 1874, 5464, 8220, 2301, 6521, 6955, 9242, 7573, 7121, 5601, 1874, 5464, 8220, 2301, 6521, 6955, 9242, 7573, 7121, 5601, 1874, 5464, 8220, 2301, 6521, 6955, 9242, 7573, 7121, 5601),
('N', 6019, 768, 6219, 2041, 7141, 3706, 7342, 4110, 3538, 4574, 6019, 768, 6219, 2041, 7141, 3706, 7342, 4110, 3538, 4574, 6019, 768, 6219, 2041, 7141, 3706, 7342, 4110, 3538, 4574, 6019),
('O', 1834, 1856, 4358, 3568, 6519, 3194, 9869, 1098, 6312, 4736, 1834, 1856, 4358, 3568, 6519, 3194, 9869, 1098, 6312, 4736, 1834, 1856, 4358, 3568, 6519, 3194, 9869, 1098, 6312, 4736, 1834),
('P', 8883, 8775, 938, 6371, 4406, 3483, 4204, 9733, 1492, 4353, 8883, 8775, 938, 6371, 4406, 3483, 4204, 9733, 1492, 4353, 8883, 8775, 938, 6371, 4406, 3483, 4204, 9733, 1492, 4353, 8883),
('Q', 2055, 7051, 1102, 5506, 1177, 2441, 2813, 1702, 4856, 8882, 2055, 7051, 1102, 5506, 1177, 2441, 2813, 1702, 4856, 8882, 2055, 7051, 1102, 5506, 1177, 2441, 2813, 1702, 4856, 8882, 2055),
('R', 5267, 4643, 2995, 8441, 9353, 3583, 8588, 8912, 8556, 7530, 5267, 4643, 2995, 8441, 9353, 3583, 8588, 8912, 8556, 7530, 5267, 4643, 2995, 8441, 9353, 3583, 8588, 8912, 8556, 7530, 5267),
('S', 2507, 2005, 4911, 2434, 6381, 3139, 3341, 728, 1926, 2282, 2507, 2005, 4911, 2434, 6381, 3139, 3341, 728, 1926, 2282, 2507, 2005, 4911, 2434, 6381, 3139, 3341, 728, 1926, 2282, 2507),
('T', 809, 3800, 1541, 1146, 7942, 629, 788, 5622, 2774, 9560, 809, 3800, 1541, 1146, 7942, 629, 788, 5622, 2774, 9560, 809, 3800, 1541, 1146, 7942, 629, 788, 5622, 2774, 9560, 809),
('U', 1666, 1568, 8027, 2576, 7440, 5291, 9101, 8153, 5817, 9470, 1666, 1568, 8027, 2576, 7440, 5291, 9101, 8153, 5817, 9470, 1666, 1568, 8027, 2576, 7440, 5291, 9101, 8153, 5817, 9470, 1666),
('V', 7958, 4782, 8557, 961, 1293, 747, 9039, 5500, 1080, 4819, 7958, 4782, 8557, 961, 1293, 747, 9039, 5500, 1080, 4819, 7958, 4782, 8557, 961, 1293, 747, 9039, 5500, 1080, 4819, 7958),
('W', 5601, 1874, 5464, 8220, 2301, 6521, 6955, 9242, 7573, 7121, 5601, 1874, 5464, 8220, 2301, 6521, 6955, 9242, 7573, 7121, 5601, 1874, 5464, 8220, 2301, 6521, 6955, 9242, 7573, 7121, 5601),
('X', 6019, 768, 6219, 2041, 7141, 3706, 7342, 4110, 3538, 4574, 6019, 768, 6219, 2041, 7141, 3706, 7342, 4110, 3538, 4574, 6019, 768, 6219, 2041, 7141, 3706, 7342, 4110, 3538, 4574, 6019),
('Y', 1834, 1856, 4358, 3568, 6519, 3194, 9869, 1098, 6312, 4736, 1834, 1856, 4358, 3568, 6519, 3194, 9869, 1098, 6312, 4736, 1834, 1856, 4358, 3568, 6519, 3194, 9869, 1098, 6312, 4736, 1834),
('Z', 8883, 8775, 938, 6371, 4406, 3483, 4204, 9733, 1492, 4353, 8883, 8775, 938, 6371, 4406, 3483, 4204, 9733, 1492, 4353, 8883, 8775, 938, 6371, 4406, 3483, 4204, 9733, 1492, 4353, 8883);

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `house` varchar(1) NOT NULL,
  `Nom` varchar(12) NOT NULL,
  `Prenom` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`house`, `Nom`, `Prenom`) VALUES
('A', 'Pierre', 'Martin'),
('B', 'Micheline', 'Dupond'),
('C', 'Albert', 'Courcoul'),
('D', 'Frédéric', 'Marchand'),
('E', 'Camille', 'Prudence'),
('F', 'Jean-Charles', 'Monvoisin'),
('G', 'Guy', 'Durand'),
('H', 'Maeva', 'Livet'),
('I', 'Alizée', 'Lieau'),
('J', 'Ségolène', 'Marchive'),
('K', 'Claude', 'Dorré'),
('L', 'Dorothée', 'Tavel'),
('M', 'Antoine', 'Dumont'),
('N', 'David', 'Alliaume'),
('O', 'Guillaume', 'Blais'),
('P', 'Alexandre', 'Jaures'),
('Q', 'Norbert', 'Detressangle'),
('R', 'Philibert', 'Usse'),
('S', 'Arthur', 'Martin'),
('T', 'Théodore', 'Javel'),
('U', 'Bruno', 'Bienvenue'),
('V', 'Pascal', 'Alison'),
('W', 'Dominique', 'Sarment'),
('X', 'Clément', 'Poirrier'),
('Y', 'Benoît', 'Luccetti'),
('Z', 'Gertrude', 'Coréa');

-- --------------------------------------------------------

--
-- Table structure for table `mytable`
--

CREATE TABLE `mytable` (
  `house` varchar(1) NOT NULL,
  `uname` varchar(23) NOT NULL,
  `password` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mytable`
--

INSERT INTO `mytable` (`house`, `uname`, `password`) VALUES
('', 'qwert', '202cb962ac590'),
('A', 'loki', '123'),
('B', 'dupontbernard', 'bFUhPDJhSRV22'),
('C', 'jf@breizh.bzh', 'LI9Ir3l2GGG1F'),
('D', '@#MJ77', 'SgPUcZA5Melq9'),
('E', '&AGENT007@', 'FDG4BQmnpNhrX'),
('F', 'MyNameIsBond', '4DFz6lnHUkQbF'),
('G', 'ZELDA', '9YjuGykEg3lKJ'),
('H', 'orangejuice', 'J5ji5bVB4ETHu'),
('I', 'whisky', 'yyrFONXCj3j9e'),
('J', 'FiestaBoomBoom69', 'aHVyZ2QMRyGY3'),
('K', 'T’envapas', 'hXzdrOVrJ4IsW'),
('L', 'martin.pierre@gmail.com', 'd2omFUd3VlyGa'),
('M', 'tonton@live.fr', 'fqlnbtHw6MQsW'),
('N', 'mika', 'gjBfU7MQccQib'),
('O', 'sansculotte1789', 'kmKEybnF8NLEp'),
('P', 'fluideglacial', 'SXsZlqiHgxURq'),
('Q', 'asterix', '89VWxOiQXTSO7'),
('R', 'Obélix', 'SBPJkSBmMTdGV'),
('S', 'Kouign-amann', 'LvMpwcCRIU889'),
('T', 'lapinou49', 'OL0N3mITyQkAz'),
('U', 'bon.jean@yahoo.fr', '0nrShtMXzYhm8'),
('V', 'tetelle', 'ipgtQp7CBhQZX'),
('W', 'liloo', 'f8bqYnLp6mhN5'),
('X', 'galinette', 'oGbKcNQFQijoP'),
('Y', 'beaulit@outlook.com', 'aOKGvxdx0aNPN'),
('Z', 'enclume69', 'cKHAvzqJ4fA2b');

-- --------------------------------------------------------

--
-- Table structure for table `tenants`
--

CREATE TABLE `tenants` (
  `Foyer` varchar(1) NOT NULL,
  `identifiant` varchar(23) NOT NULL,
  `password` varchar(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`) VALUES
(1, 'shashi', 'shashi', 'shashi'),
(2, 'loki', 'shashikiran330@gmail.com', '202cb962ac59075b964b07152d234b70'),
(3, 'qwe', 'skdhjgjhvc@jshdfgsdbc', 'c20ad4d76fe97759aa27a0c99bff6710'),
(4, 'varsha', 'skdgfsdgfsodvhbn@gmaof.com', ''),
(5, 'abcd', 'ajkfdbalsdj@shdjgf.ocm', '202cb962ac59075b964b07152d234b70'),
(6, 'shashi', 'shashikir@gmail.com', '202cb962ac59075b964b07152d234b70');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`house`);

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`house`);

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`house`);

--
-- Indexes for table `mytable`
--
ALTER TABLE `mytable`
  ADD PRIMARY KEY (`house`);

--
-- Indexes for table `tenants`
--
ALTER TABLE `tenants`
  ADD PRIMARY KEY (`Foyer`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
